<?php

//---------------- fonction de debug -------------------

function debug($param){
	echo'<pre>';
		print_r($param);
	echo '</pre>';
}

//--------------- fonction membres ---------------------

// Fonction qui indique si l'internaute est connect� :
function internauteEstConnecte(){
	if (isset($_SESSION['membre'])){ // si la session "membre" existe, c'est que l'internaute est pass� par la page de connexion et que nous avons cr�� cet indice dans $_SESSION
		return true;
	} else {
		return false;
	}
	// OU :
	return (isset($_SESSION['membre']))
}